Instructions for Running Code:

For the main HW:
Please run everything then java EmailMenu.

NOTE:  Somehow my compose doesn't work, but everything else/should.
I have no idea what broke it- if I can't fix it I'll email you further about it.

NOTE:  AFTER INITIAL SUBMISSION:
Everything should work now- I spent the night fixing it.  I understand that this
is essentially a late submission and you might not grade this, but note that this
should work now.  Everything should also have complete documentation as well.
